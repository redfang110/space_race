﻿
using var game = new Space_Race.Game1();
game.Run();
